# Amawizard

Amazon affiliate site for UK kitchen gadgets. Built with React + Vite.